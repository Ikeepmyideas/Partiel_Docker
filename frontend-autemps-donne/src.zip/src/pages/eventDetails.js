import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import '../css/admin.css';
import NavMenu from './navMenu';
import horlogeIcon from '../assets/horloge.png'; // Ensure you use this if needed

function EventDetails() {
    const { eventId } = useParams(); // Correctly capturing the event ID from the URL
    const [event, setEvent] = useState(null);

    useEffect(() => {
        // Use template literals to include eventId dynamically
        fetch(`http://127.0.0.1:8000/api/admin/activites/${eventId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Erreur réseau');
                }
                return response.json();
            })
            .then(data => {
                setEvent(data);
            })
            .catch(error => {
                console.error('Erreur lors de la récupération des détails de l’événement:', error);
            });
    }, [eventId]); // Dependency array ensures useEffect is called again if eventId changes

    if (!event) {
        return <div>Loading...</div>; // Handle loading state
    }

    return (
        <>
            <NavMenu />
            <section className="content">
                <div className="event-details">
                    <h2>{event.titre}</h2>
                    <div className="infos">
                        <img src={`assets/${event.image}`} alt={event.titre || "Event"} style={{ height: '180px', borderRadius: '25px' }} />
                        <div>
                            <p>Date: {event.date_activite ? new Date(event.date_activite).toLocaleDateString() : 'Date not available'}</p>
                            <p>Heure de début: {event.heure_debut || 'Not specified'}</p>
                            <p>Description: {event.description || 'No description provided'}</p>
                            <div className="adresse">
                                <p>Adresse: {event.lieu ? event.lieu.adresse : 'Not specified'}</p>
                                <p>Code postal: {event.lieu ? event.lieu.code_postal : 'Not specified'}</p>
                                <p>Ville: {event.lieu ? event.lieu.ville : 'Not specified'}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
}

export default EventDetails;
