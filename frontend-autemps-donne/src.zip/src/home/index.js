import React from 'react';
import './index.css';
import { Link } from 'react-router-dom';


function Home() {
    const handleSignupClick = () => {
      window.location.href = '/signup'; // Redirect to the signup page
    };
  return (
    <>
      <html lang="en">

      <body>
          
        <header class="header" data-header>
          <div class="container">
      
            <h1>
              <a href="../assets/images/logo.png" class="logo">Au temps donnée</a>
              <img href="../assets/images/logo.png" class="logo"/>
            </h1>
            <select name="language" class="lang-switch">
              <option value=""></option>
              <option value="english">English</option>
              <option value="french">French</option>
      
            </select>
            <button class="nav-open-btn" aria-label="Open Menu" data-nav-open-btn>
              <ion-icon name="menu-outline"></ion-icon>
            </button>
      
            <nav class="navbar" data-navbar>
      
              <button class="nav-close-btn" aria-label="Close Menu" data-nav-close-btn>
                <ion-icon name="close-outline"></ion-icon>
              </button>
      
              <img href="../assets/images/logo.png" class="logo"/>
      
              <ul class="navbar-list">
      
                <li>
                  <a href="#Accueil" class="navbar-link" data-nav-link>
                    <span>Accueil</span>
      
                    <ion-icon name="chevron-forward-outline" aria-hidden="true"></ion-icon>
                  </a>
                </li>
      
                <li>
                  <a href="#A_Propost" class="navbar-link" data-nav-link>
                    <span>A Propos de Nous</span>
      
              <ion-icon name="chevron-forward-outline" aria-hidden="true"></ion-icon>
          </a>
        </li>
      
        <li>
          <a href="#Evenements" class="navbar-link" data-nav-link>
            <span>Evenements</span>
      
            <ion-icon name="chevron-forward-outline" aria-hidden="true"></ion-icon>
          </a>
        </li>
      
        <li>
          <a href="#Dons" class="navbar-link" data-nav-link>
            <span>Dons</span>
      
            <ion-icon name="chevron-forward-outline" aria-hidden="true"></ion-icon>
          </a>
        </li>
      
        <li>
          <a href="#Blogt" class="navbar-link" data-nav-link>
            <span>Blog</span>
      
            <ion-icon name="chevron-forward-outline" aria-hidden="true"></ion-icon>
          </a>
        </li>
      
        <li>
          <a href="#" class="navbar-link" data-nav-link>
            <span>Contact</span>
      
            <ion-icon name="chevron-forward-outline" aria-hidden="true"></ion-icon>
          </a>
        </li>
      
      </ul>
      
      </nav>
      
      <div class="header-action">
      
        <button class="search-btn" aria-label="Search">
          <ion-icon name="search-outline"></ion-icon>
        </button>
      
        <Link  type="submit" class="btn btn-primary" to="signup">Connexion</Link>
        <ion-icon name="enter-outline" aria-hidden="true"></ion-icon>

      </div>
      
      </div>
          </header>
          <main>
            <article>
              <section class="hero" id="home">
                <div class="container">
      
                  <p class="section-subtitle">
                    <img src="../assets/images/kindnesshands.jpeg" width="32" height="7" alt="Wavy line"/>
        
                    <span>Bienvenue Au temps Donnée</span>
                  </p>
                  <h2 class="h1 hero-title">
                    Ensemble,<strong>Changeons les choses</strong>
                  </h2>
        
                  <p class="hero-text">
                    Donnons un coup de main à ceux dans le besoin
                  </p>
                  <form action="../Inscription/signup.html">
                <button type="submit" onClick={handleSignupClick} class="btn btn-primary">
                    <span>Inscription</span>
                    <ion-icon name="enter-outline" aria-hidden="true"></ion-icon>
                </button>
            </form>
              
                  
                </div>
              </section>
      
            <section class="section about" id="about">
              <div class="container">
      
                <div class="about-banner">
      
                  <h2 class="deco-title">About Us</h2>
      
                  <img src="../assets/images/deco-img.png" width="58" height="261" alt="" class="deco-img"/>
      
                  <div class="banner-row">
      
                    <div class="banner-col">
                      <img src="../assets/images/Duo-riverain_sdf-femme-trottoir-1.jpeg" width="315" height="380" loading="lazy" alt="Aide_sdf"
                        class="about-img w-100"/>
      
                      <img src="../assets/images/cover-personnes-agees.jpeg" width="386" height="250" loading="lazy" alt="Personnes_ages"
                        class="about-img about-img-2 w-100"/>
                    </div>
      
                    <div class="banner-col">
                      <img src="../assets/images/Maraude 5 - Une 675.jpeg" width="250" height="277" loading="lazy" alt="Maraude_5"
                        class="about-img about-img-3 w-100"/>
      
                      <img src="../assets/images/accueilcrèche.jpeg" width="315" height="380" loading="lazy" alt="Creche"
                        class="about-img w-100"/>
                    </div>
                    </div>
                  </div>
                </div>
      
                <div class="about-content">
      
                  <p class="section-subtitle">
                    <img src="../assets/images/subtitle-img-white.png" width="32" height="7" alt="Wavy line"/>
      
                    <span>Pourquoi nous rejoindre </span>
                  </p>
      
                  <h2 class="h2 section-title">
                    Pour tendre une main <strong> à son prochain</strong>
                  </h2>
      
                  <ul class="tab-nav">
      
                    <li>
                      <button class="tab-btn active">Notre Mission</button>
                    </li>
      
                    <li>
                      <button class="tab-btn">Notre Vision</button>
                    </li>
      
                    <li>
                      <button class="tab-btn">Nos Plans</button>
                    </li>
      
                  </ul>
                  <div class="tab-content">
      
                    <p class="section-text">
                      But I must explain to you how all this mistaken denouncing pleasure and praising pain was born and I
                      will give you a
                      complete account of the system expoundmaster
                    </p>
      
                    <ul class="tab-list">
      
                      <li class="tab-item">
                        <div class="item-icon">
                          <ion-icon name="checkmark-circle"></ion-icon>
                        </div>
      
                        <p class="tab-text">Dons pour l'alimentaire</p>
                      </li>
      
                      <li class="tab-item">
                        <div class="item-icon">
                          <ion-icon name="checkmark-circle"></ion-icon>
                        </div>
      
                        <p class="tab-text">Dons pour l'éducation</p>
                      </li>
      
                      <li class="tab-item">
                        <div class="item-icon">
                          <ion-icon name="checkmark-circle"></ion-icon>
                        </div>
      
                        <p class="tab-text">Assistance administrative </p>
                      </li>
      
                      <li class="tab-item">
                        <div class="item-icon">
                          <ion-icon name="checkmark-circle"></ion-icon>
                        </div>
      
                        <p class="tab-text">Assistance personelle</p>
                      </li>
      
                    </ul>
      
                    <button class="btn btn-secondary">
                      <span>A propos de nous</span>
      
                      <ion-icon name="" aria-hidden="true"></ion-icon>
                    </button>
      
                  </div>
      
              </div>
            </section>
      
            <section class="section cta">
              <div class="container">
      
                <div class="cta-content">
                  <h2 class="h2 section-title">45+ Partenaires</h2>
      
                  <button class="btn btn-outline">
                    <span>Devenir Partenaires</span>
      
                    <ion-icon name="heart-outline" aria-hidden="true"></ion-icon>
                  </button>
                </div>
                <figure class="cta-banner">
                  <img src="../assets/images/bannière-partenaire2.png" width="520" height="228" loading="lazy" alt="Fox"
                    class="img-cover"/>
                </figure>
      
              </div>
            </section>


            </article>
          </main>
          
          <script src="home.js"></script>
           <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
            <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
        
          <footer class="footer">
            <div class="container">
      
              <ul class="footer-list">
      
                <li>
                  <a href="#" class="footer-link">Terms of use</a>
                </li>
      
                <li>
                  <a href="#" class="footer-link">Privacy & Policy</a>
                </li>
      
              </ul>
      
              <p class="copyright">
                Copyright 2024<a href="#" class="copyright-link">Au Temps Donnée</a>. All Rights Reserved.
              </p>
      
            </div>
          </footer>
        </body>
        </html>
    </>
  );
}

export default Home;
